# Miftāḥ — مِفْتَاح

**Prototyp eines erklärend-enzyklopädischen Wörterbuchs kulturgebundener islamischer Schlüsselbegriffe für deutschsprachige Konvertierte.**

Masterarbeit von Ahmed Shaita (2026). Universität de Lorraine. Betreuung: Frau Anja Smith.

## Stand des Prototyps

Diese Version zeigt alle **sechs Lemmata** des Initialkorpus mit dem jeweils aktuellen Bearbeitungsstand. Die Architektur ist vollständig implementiert; die inhaltliche Befüllung wächst iterativ.

| Lemma | Arabisch | Bedeutung | Stand |
|---|---|---|---|
| Taqwā | تَقْوَى | Gottesbewusstsein | ✓ Vollständig |
| Zakāt | زَكَاة | Pflichtabgabe | 45 % bearbeitet |
| Ṣadaqa | صَدَقَة | Freiwillige Spende | 45 % bearbeitet |
| Ṣalāh | صَلَاة | Pflichtgebet | 40 % bearbeitet |
| Īmān | إِيمَان | Glaube | 30 % bearbeitet |
| Dīn | دِين | Religion / Lebensweise | 25 % bearbeitet |

Sichtbare „Zu liefern"-Boxen in den Einträgen markieren, was inhaltlich noch zu ergänzen ist.

## Aufbau

- **Modulare Mikrostruktur** mit acht Modulen pro Eintrag (drei Pflicht-, fünf Optionsmodule)
- **Typisierte Verweise** (Kohyponym, Antonym, etymologisch verwandt)
- **Thematische Erschließung** über fünf semantische Felder
- **Kuratierte Lernpfade** für didaktische Sequenzen
- **Volltextsuche** über arabische Schrift, Umschrift und Übersetzung

## Technologie

Reines HTML, CSS und JavaScript ohne Framework. Schriftarten von Google Fonts (Inter, Amiri). Keine Build-Schritte erforderlich.

## Lizenz

Die Konzeption und der Code dieses Prototyps sind im Rahmen der Masterarbeit entstanden. Verwendung über die wissenschaftliche Begutachtung hinaus nach Absprache mit dem Verfasser.
